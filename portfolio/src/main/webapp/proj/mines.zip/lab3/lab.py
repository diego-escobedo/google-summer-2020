"""6.009 Lab 3 -- HyperMines"""

import sys
sys.setrecursionlimit(10000)
# NO ADDITIONAL IMPORTS


class HyperMinesGame:
    def __init__(self, dimensions, bombs):
        """Start a new game.

        This method should properly initialize the "board", "mask",
        "dimensions", and "state" attributes.

        Args:
           dimensions (list): Dimensions of the board
           bombs (list): Bomb locations as a list of lists, each an
                         N-dimensional coordinate
        """
        self.dimensions = dimensions
        self.mask = self.make_board(dimensions, False)
        self.board = self.make_board(dimensions, 0)
        self.state = "ongoing"
        
        
        all_coord_list_of_lists = []
        for dim in self.dimensions:
            all_coord_list_of_lists.append(list(range(dim)))
        self.list_of_all_coords = self.all_coords(all_coord_list_of_lists)
        
        for bomb_coord in bombs:
            self.set_coords(bomb_coord, ".")
            for neighbor_coord in self.neighbors(bomb_coord):
                if self.get_coords(neighbor_coord) != ".":
                    val = int(self.get_coords(neighbor_coord))
                    self.set_coords(neighbor_coord, val + 1)
                    
    def all_coords(self, big_list):
        pools = [tuple(rang) for rang in big_list]
        result = [[]]
        newr = []
        for pool in pools:
            result = [x+[y] for x in result for y in pool]
        for prod in result:
            temp = tuple(prod)
            newr.append(temp)
        return newr 

    def get_coords(self, coords, board = None):
        """Get the value of a square at the given coordinates on the board.
    
        (Optional) Implement this method to return the value of a square at the given
        coordinates.
    
        Args:
            coords (list): Coordinates of the square
    
        Returns:
            any: Value of the square
        """
        if board == None:
            board = self.board
        tmp = board
        for val in coords:
            tmp = tmp[val]
        return tmp    
    
    def set_coords(self, coords, value, board = None):
        """Set the value of a square at the given coordinates on the board.
    
        (Optional) Implement this method to set the value of a square at the given
        coordinates.
        
        Args:
            coords (list): Coordinates of the square
        """
        if board == None:
            board = self.board
        tmp = board
        for val in coords[:-1]:
            tmp = tmp[val]
        tmp[coords[-1]] = value
        

    def make_board(self, dimensions, elem, depth = 0):
        """Return a new game board

        (Optional) Implement this method to return a board of N-Dimensions.

        Args:
            dimensions (list): Dimensions of the board
            elem (any): Initial value of every square on the board

        Returns:
            list: N-Dimensional board
        """
        if len(dimensions) != depth:
            return [self.make_board(dimensions,elem, depth+1) for i in range(dimensions[depth])]
        else:
            return elem    

    def neighbors(self, coords):
        N = len(coords)
        neighbs = []
        tups_of_perturbs = self.get_0s_and_1s(repeat=N)
        for altered_index in tups_of_perturbs:
            new_neighb = tuple(coord + mod for coord, mod in zip(coords, altered_index))
            is_neighb_valid = True
            for i in range(len(new_neighb)):
                if new_neighb[i] >= self.dimensions[i] or new_neighb[i] < 0:
                    is_neighb_valid = False
                    break
            if is_neighb_valid:
                neighbs.append(new_neighb)
        
        return neighbs
                
    def get_0s_and_1s(self, repeat=1):
        pools = [(-1, 0, 1)] * repeat 
        result = [[]]
        newr = []
        for pool in pools:
            result = [x+[y] for x in result for y in pool]
        result.remove([0]*repeat)
        for prod in result:
            temp = tuple(prod)
            newr.append(temp)
        return newr

    def is_victory(self):
        """Returns whether there is a victory in the game.

        A victory occurs when all non-bomb squares have been revealed.
        (Optional) Implement this method to properly check for victory in an N-Dimensional board.

        Returns:
            boolean: True if there is a victory and False otherwise
        """
        
        for coord in self.list_of_all_coords:
            if self.get_coords(coord, self.mask) and self.get_coords(coord) == ".":
                return False
            if not self.get_coords(coord, self.mask) and self.get_coords(coord) != ".":
                return False
        return True

    def dig(self, coords):
        """Recursively dig up square at coords and neighboring squares.

        Update the mask to reveal square at coords; then recursively reveal its
        neighbors, as long as coords does not contain and is not adjacent to a
        bomb.  Return a number indicating how many squares were revealed.  No
        action should be taken and 0 returned if the incoming state of the game
        is not "ongoing".

        The updated state is "defeat" when at least one bomb is visible on the
        board after digging, "victory" when all safe squares (squares that do
        not contain a bomb) and no bombs are visible, and "ongoing" otherwise.

        Args:
           coords (list): Where to start digging

        Returns:
           int: number of squares revealed
        """
        if self.state != "ongoing" or self.get_coords(coords, self.mask) == True:
            return 0
        
        self.set_coords(coords, True, self.mask)
        
        if self.get_coords(coords) == ".":
            self.state = "defeat"
            return 1
        
        count = 1        
        if self.get_coords(coords) == 0: # if digging up a regular square, recursively dig its neighbors
            neighbors = self.neighbors(coords)
            for neighbor in neighbors:                
                count += self.dig(neighbor)
        if self.is_victory():
            self.state = 'victory'
        else:
            self.state = 'ongoing'
        return count

    def render(self, xray=False):
        """Prepare the game for display.

        Returns an N-dimensional array (nested lists) of "_" (hidden squares),
        "." (bombs), " " (empty squares), or "1", "2", etc. (squares
        neighboring bombs).  The mask indicates which squares should be
        visible.  If xray is True (the default is False), the mask is ignored
        and all cells are shown.

        Args:
           xray (bool): Whether to reveal all tiles or just the ones allowed by
                        the mask

        Returns:
           An n-dimensional array (nested lists)
        """
        
        new_board = self.make_board(self.dimensions, None)
        for coord in self.list_of_all_coords:
            if self.get_coords(coord, self.mask) == True or xray:
                coord_at_loc = self.get_coords(coord)
                if coord_at_loc == 0:
                    self.set_coords(coord, " " , new_board)
                elif coord_at_loc == ".":
                    self.set_coords(coord, "." , new_board)
                else:
                    self.set_coords(coord, str(coord_at_loc) , new_board)
            else:
                self.set_coords(coord, str("_"), new_board)
        return new_board
        
        

    # ***Methods below this point are for testing and debugging purposes only. Do not modify anything here!***

    def dump(self):
        """Print a human-readable representation of this game."""
        lines = ["dimensions: %s" % (self.dimensions, ),
                 "board: %s" % ("\n       ".join(map(str, self.board)), ),
                 "mask:  %s" % ("\n       ".join(map(str, self.mask)), ),
                 "state: %s" % (self.state, )]
        print("\n".join(lines))

    @classmethod
    def from_dict(cls, d):
        """Create a new instance of the class with attributes initialized to
        match those in the given dictionary."""
        game = cls.__new__(cls)
        for i in ('dimensions', 'board', 'state', 'mask'):
            setattr(game, i, d[i])
        return game