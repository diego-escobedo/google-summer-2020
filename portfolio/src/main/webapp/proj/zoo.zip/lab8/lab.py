"""6.009 Spring 2019 Lab 8 -- 6.009 Zoo"""

# NO IMPORTS ALLOWED!

class Constants:
    """
    A collection of game-specific constants.

    You can experiment with tweaking these constants, but
    remember to revert the changes when running the test suite!
    """
    # width and height of keepers
    KEEPER_WIDTH = 31
    KEEPER_HEIGHT = 31

    # width and height of animals
    ANIMAL_WIDTH = 31
    ANIMAL_HEIGHT = 31

    # width and height of food
    FOOD_WIDTH = 11
    FOOD_HEIGHT = 11

    # width and height of rocks
    ROCK_WIDTH = 51
    ROCK_HEIGHT = 51

    # thickness of the path
    PATH_THICKNESS = 31

    TEXTURES = {
        'rock': '1f5ff',
        'animal': '1f418',
        'SpeedyZookeeper': '1f472',
        'ThriftyZookeeper': '1f46e',
        'OverreachingZookeeper': '1f477',
        'food': '1f34e'
    }

    KEEPER_INFO = {'SpeedyZookeeper':
                   {'price': 250,
                    'range': 50,
                    'throw_speed_mag': 20},
                   'ThriftyZookeeper':
                   {'price': 100,
                    'range': 100,
                    'throw_speed_mag': 15},
                   'OverreachingZookeeper':
                   {'price': 150,
                    'range': 150,
                    'throw_speed_mag': 5}
                   }


class NotEnoughMoneyError(Exception):
    """A custom exception to be used when insufficient funds are available
    to hire new zookeepers."""
    pass



################################################################################
################################################################################
# Static methods.

def distance(a, b):
    """Returns the Euclidian distance between the two tuple coordinates."""
    return ((a[0] - b[0]) ** 2 + (a[1] - b[1]) ** 2) ** 0.5

    


################################################################################
################################################################################

class Game:
    def __init__(self, game_info):
        """Initializes the game.

        `game_info` is a dictionary formatted in the following manner:
          { 'width': The width of the game grid, in an integer (i.e. number of pixels).
            'height': The height of the game grid, in an integer (i.e. number of pixels).
            'rocks': The set of tuple rock coordinates.
            'path_corners': An ordered list of coordinate tuples. The first
                            coordinate is the starting point of the path, the
                            last point is the end point (both of which lie on
                            the edges of the gameboard), and the other points
                            are corner ("turning") points on the path.
            'money': The money balance with which the player begins.
            'spawn_interval': The interval (in timesteps) for spawning animals
                              to the game.
            'animal_speed': The magnitude of the speed at which the animals move
                            along the path, in units of grid distance traversed
                            per timestep.
            'num_allowed_unfed': The number of animals allowed to finish the
                                 path unfed before the player loses.
          }
        """
        self.grid_size_tup = (game_info["width"], game_info["height"]) #numrows, numcols
        self.rockset = set()
        for coord in game_info["rocks"]:
            self.rockset.add(Rock(coord, "rock"))
        self.path_corners_lst = game_info["path_corners"]
        self.money = game_info["money"]
        self.spawn_interval = game_info["spawn_interval"]
        self.animal_speed = game_info["animal_speed"]
        self.max_unfed = game_info["num_allowed_unfed"]
        self.current_timestep = -1
        self.animals = []
        self.zookeepers = []
        self.food = []
        self.all_possible_coords = self.get_all_coords(self.path_corners_lst)
        self.passed_defenses = 0
        self.mouse_selected_zookeeper = None
        self.defeated = False
        self.path_polys = self.segment_path()

    def render(self):
        """Renders the game in a form that can be parsed by the UI.

        Returns a dictionary of the following form:
          { 'formations': A list of dictionaries in any order, each one
                          representing a formation. Each dictionary is of the form
                            `{'loc': (x, y),
                              'texture': texture,
                              'size': (width, height)}`
                          where `(x,y)` is the center coordinate of the formation,
                          `texture` is its texture, and it has `width` and `height`
                          dimensions. The dictionary should contain the
                          formations of all animals, zookeepers, rocks, and food.
            'money': The amount of money the player has available.
            'status': The current state of the game which can be 'ongoing' or 'defeat'.
            'num_allowed_remaining': The number of animals which are still
                                     allowed to exit the board before the game
                                     status is `'defeat'`.
          }
        """
        render_dict = {}
        render_dict["formations"] = []
        for animal in self.animals:
            render_dict["formations"].append({'loc': animal.center_location,'texture': animal.texture,'size': animal.size})
        for food in self.food:
            render_dict["formations"].append({'loc': food.center_location,'texture': food.texture,'size': food.size})
        for zookeeper in self.zookeepers:
            render_dict["formations"].append({'loc': zookeeper.center_location,'texture': zookeeper.texture,'size': zookeeper.size})
        for rock in self.rockset:
            render_dict["formations"].append({'loc': rock.center_location,'texture': rock.texture,'size': rock.size})
        render_dict["money"] = self.money
        if self.defeated:
            render_dict["status"] = "defeat"
        else:
            render_dict["status"] = "ongoing"
        render_dict["num_allowed_remaining"] = self.max_unfed - self.passed_defenses
        return render_dict
                                  

    def timestep(self, mouse=None):
        """Simulates the evolution of the game by one timestep.

        In this order:
            (0. Do not take any action if the player is already defeated.)
            1. Compute any changes in formation locations, and remove any
                off-board formations.
            2. Handle any food-animal collisions, and remove the fed animals
                and eaten food.
            3. Throw new food if possible.
            4. Spawn a new animal from the path's start if needed.
            5. Handle mouse input, which is the integer coordinate of a player's
               click, the string label of a particular zookeeper type, or `None`.
            6. Redeem one unit money per animal fed this timestep.
            7. Check for the losing condition to update the game status if needed.
        """
        self.current_timestep += 1
        #------------------------ step 0: check defeat
        if self.defeated:
            return
        #------------------------ step 1: move formations
            #------ substep: animals
        lst_to_remove = []
        for animal in self.animals: 
            if not self.move_animal(animal):
                lst_to_remove.append(animal)
        for elem in lst_to_remove:
            self.animals.remove(elem)
            self.passed_defenses += 1
            #------ substep: food
        lst_to_remove = []
        for food in self.food: #animal_tup is (animal_id, animal obj)
            if not self.move_food(food):
                lst_to_remove.append(food)
        for elem in lst_to_remove:
            self.food.remove(elem)      
        #------------------------ step 2: food animal collisions
        lst_to_rm_animals = set()
        lst_to_rm_food = set()
        currency_earned = 0
        for animal in self.animals:
            for food in self.food:
                if food not in lst_to_rm_food:
                    if self.formations_intersect(food, animal):
                        lst_to_rm_animals.add(animal)
                        lst_to_rm_food.add(food)
        currency_earned += len(lst_to_rm_animals)
        for elem in lst_to_rm_animals:
            self.animals.remove(elem)  
        for elem in lst_to_rm_food:
            self.food.remove(elem)
        #------------------------ step 3: throw new food
        self.throw_new_food()
        #------------------------ step 4: spawn new animal      
        if self.current_timestep%self.spawn_interval == 0:
            self.spawn_animal()
        #------------------------ step 5: handle mouse input
        if isinstance(mouse,str):
            self.mouse_selected_zookeeper = mouse
        elif isinstance(mouse,tuple):
            possible_zook = Zookeeper(mouse, self.mouse_selected_zookeeper, self.all_possible_coords)
            if self.money < possible_zook.price:
                raise NotEnoughMoneyError
            else:
                valid_pos = True
                for rock in self.rockset:
                    if not valid_pos:
                        break
                    if self.formations_intersect(rock, possible_zook):
                        valid_pos = False
                for zookeeper in self.zookeepers:
                    if not valid_pos:
                        break
                    if self.formations_intersect(zookeeper, possible_zook):
                        valid_pos = False
                if self.intersect_path(possible_zook) and valid_pos:
                    valid_pos = False
                if valid_pos:
                    self.zookeepers.append(possible_zook)
                    self.mouse_selected_zookeeper = None
                    self.money -= possible_zook.price
                else:
                    pass
        else: #input is none
            pass
        #------------------------ step 6: redeem one dollar per animal fed
        self.money += currency_earned
        #------------------------ step 7: check losing condition
        if self.passed_defenses > self.max_unfed:
            self.defeated = True
            
        
    def formations_intersect(self, formation1, formation2):
        difference_x = abs(formation1.center_location[0] - formation2.center_location[0])
        sum_half_widths_x = 0.5*(formation1.size[0] + formation2.size[0])
        difference_y = abs(formation1.center_location[1] - formation2.center_location[1])
        sum_half_widths_y = 0.5*(formation1.size[1] + formation2.size[1])
        if difference_x < sum_half_widths_x and difference_y < sum_half_widths_y:
            return True
        return False
    
    def intersect_path(self, zookeeper):      
        for path_block in self.path_polys:
            if self.formations_intersect(path_block, zookeeper):
                return True
        return False
    
    def segment_path(self):
        retlist = []
        for i in range(len(self.path_corners_lst)-1):
            start_coord = self.path_corners_lst[i]
            end_coord = self.path_corners_lst[i+1]
            retlist.append(Path(start_coord, end_coord))
        return retlist            
    
    def spawn_animal(self):
        self.animals.append(  Animal(self.path_corners_lst[0], "animal")  )
        
    def throw_new_food(self):
        for zookeeper in self.zookeepers:
            aim_animal = None
            for coord in zookeeper.coords_in_sight:
                aim_animal_found = False
                for animal in self.animals:
                    if animal.center_location == coord:
                        aim_animal = animal
                        aim_animal_found = True
                        break
                if aim_animal_found:
                    break
            if aim_animal == None:
                continue
            coord_diffs_tup = (None, 999999999) #shortest diff
            start_calculating = False
            aim_animal_index = self.all_possible_coords.index(aim_animal.center_location)
            for i in range(len(self.all_possible_coords)):
                if start_calculating:
                    timesteps_until_coord_animal = (i - aim_animal_index)/self.animal_speed
                    timesteps_until_coord_food = distance(self.all_possible_coords[i], zookeeper.center_location)/zookeeper.throw_speed
                    diff = abs(timesteps_until_coord_animal - timesteps_until_coord_food)
                    if diff < coord_diffs_tup[1]:
                        coord_diffs_tup = (self.all_possible_coords[i], diff)
                    
                if self.all_possible_coords[i] == aim_animal.center_location:
                    start_calculating = True
                    
            self.food.append(Food(zookeeper.center_location, "food", zookeeper, coord_diffs_tup[0]))
    
    def move_animal(self, animal):
        i = self.all_possible_coords.index(animal.center_location)
        try:
            animal.center_location = self.all_possible_coords[i+self.animal_speed]
            return True
        except:
            return False
    
    def move_food(self, food):
        food.center_location = (food.center_location[0] + food.x_per_timestep, food.center_location[1] + food.y_per_timestep)
        if food.center_location[0] > self.grid_size_tup[0] or food.center_location[0] < 0:
            return False
        if food.center_location[1] > self.grid_size_tup[1] or food.center_location[0] < 0:
            return False
        return True
    
    def get_all_coords(self,lst_coords):
        retlist = []
        for i in range(len(lst_coords)-1):
            corner1 = lst_coords[i]
            corner2 = lst_coords[i+1]
            if corner1[0] == corner2[0]: #this means they're the same vertically
                if corner1[1] > corner2[1]:             
                    for k in range(0, corner2[1] - corner1[1], -1):
                        retlist.append(   (  corner1[0], corner1[1] + k)  )
                elif corner1[1] < corner2[1]:             
                    for k in range(corner2[1] - corner1[1]):
                        retlist.append(   (  corner1[0], corner1[1] + k)  )
            elif corner1[1] == corner2[1]: #this means theyre the same horizontally
                if corner1[0] > corner2[0]:             
                    for k in range(0, corner2[0] - corner1[0], -1):
                        retlist.append(   (  corner1[0] + k, corner1[1])  )
                elif corner1[0] < corner2[0]:             
                    for k in range(corner2[0] - corner1[0]):
                        retlist.append(   (  corner1[0] + k, corner1[1])  ) 
        retlist.append(lst_coords[-1])
        return retlist
        



################################################################################
################################################################################
# TODO: Add additional classes here.

class Formations(Constants):
    def __init__(self, location, f_type):
        self.texture = self.TEXTURES[f_type]
        self.center_location = location # IN THE FORM (X,Y)           
            
class Zookeeper(Formations):
    def __init__(self, location, f_type, all_coords):
        super().__init__(location, f_type)
        self.size = (self.KEEPER_WIDTH, self.KEEPER_HEIGHT)
        self.keeper_type = f_type
        all_coords_prioritized = all_coords[::-1]
        self.coords_in_sight = []
        self.price = self.KEEPER_INFO[self.keeper_type]["price"]
        self.throw_speed = self.KEEPER_INFO[self.keeper_type]["throw_speed_mag"]
        for coord in all_coords_prioritized:
            if distance(coord, self.center_location) <= self.KEEPER_INFO[self.keeper_type]["range"]:
                self.coords_in_sight.append(coord)

class Animal(Formations):
    def __init__(self, location, f_type):
        super().__init__(location, f_type)
        self.size = (self.ANIMAL_WIDTH, self.ANIMAL_HEIGHT)
        
class Rock(Formations):
    def __init__(self, location, f_type):
        super().__init__(location, f_type)
        self.size = (self.ROCK_WIDTH, self.ROCK_HEIGHT)
        
class Food(Formations):
    def __init__(self, location, f_type, originating_zookeeper, destination):
        super().__init__(location, f_type)
        self.size = (self.FOOD_WIDTH, self.FOOD_HEIGHT)
        speed = originating_zookeeper.throw_speed
        originating_location = originating_zookeeper.center_location
        diffx, diffy = (destination[0] - originating_location[0], destination[1] - originating_location[1])
        self.x_per_timestep = diffx/((diffx**2 + diffy**2)/speed**2)**0.5
        self.y_per_timestep = diffy/((diffx**2 + diffy**2)/speed**2)**0.5
        
class Path(Formations):
    def __init__(self, start_coord, end_coord):
        self.texture = None
        thicc = self.PATH_THICKNESS
        if start_coord[0] == end_coord[0]: #in this case, vertical segment
            if abs( start_coord[1] - (end_coord[1] + thicc/2) ) > abs( start_coord[1] - (end_coord[1] - thicc/2) ):
                new_y = end_coord[1] + thicc/2
            else:
                new_y = end_coord[1] - thicc/2
            self.size = (thicc, abs(new_y - start_coord[1]))
            self.center_location = (start_coord[0], (new_y + start_coord[1])/2)
        elif start_coord[1] == end_coord[1]: #in this case, horizontal segment
            if abs( start_coord[0] - (end_coord[0] + thicc/2) ) > abs( start_coord[0] - (end_coord[0] - thicc/2) ):
                new_x = end_coord[0] + thicc/2
            else:
                new_x = end_coord[0] - thicc/2
            self.size = (abs(new_x - start_coord[0]), thicc)
            self.center_location = ((new_x + start_coord[0])/2, start_coord[1])
        

################################################################################
################################################################################



if __name__ == '__main__':
   pass
